export const ProductModel = {
  product: {
    description: '',
    id: '',
    name: '',
    price: 0.0
  },
  products: [],
  loading: false,
}

export default ProductModel;
