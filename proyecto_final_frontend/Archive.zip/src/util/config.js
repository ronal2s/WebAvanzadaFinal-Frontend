module.exports = {
  footerText: 'Sistema multimedia, 2020',
}
