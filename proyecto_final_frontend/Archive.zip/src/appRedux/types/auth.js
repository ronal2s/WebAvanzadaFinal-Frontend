import { createTypes } from "../helpers/reduxHelper";

export const SIGN_IN = createTypes('AUTH/SIGN_IN');
